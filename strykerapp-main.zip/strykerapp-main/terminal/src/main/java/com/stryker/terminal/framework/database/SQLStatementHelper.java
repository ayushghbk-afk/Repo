package com.stryker.terminal.framework.database;

import com.stryker.terminal.framework.database.bean.TableInfo;
import com.stryker.terminal.framework.database.annotation.ID;
import com.stryker.terminal.framework.database.bean.TableInfo;

import java.lang.reflect.Field;

public class SQLStatementHelper {

  public static String createTable(TableInfo tableInfo) {
    StringBuilder statement = new StringBuilder();

    statement.append("CREATE TABLE ").append("'")
      .append(tableInfo.tableName).append("'")
      .append(" (");

    if (tableInfo.containID) {
      DatabaseDataType dataType = SQLTypeParser.getDataType(tableInfo.primaryField);
      if (dataType == null) {
        throw new IllegalArgumentException("Type of " + tableInfo.primaryField.getType().getName() + " is not support in WelikeDB.");
      }
      statement.append("'").append(tableInfo.primaryField.getName()).append("'");
      switch (dataType) {
        case INTEGER:
          statement.append(" INTEGER PRIMARY KEY ");
          ID id = tableInfo.primaryField.getAnnotation(ID.class);
          if (id != null && id.autoIncrement()) {
            statement.append("AUTOINCREMENT");
          }
          break;
        default:
          statement
            .append("  ")
            .append(dataType.name())
            .append(" PRIMARY KEY");
      }

      statement.append(",");


    } else {
      statement.append("'_id' INTEGER PRIMARY KEY AUTOINCREMENT,");
    }


    for (Field field : tableInfo.fieldToDataTypeMap.keySet()) {
      DatabaseDataType dataType = tableInfo.fieldToDataTypeMap.get(field);
      statement.append("'").append(field.getName()).append("'")
        .append(" ")
        .append(dataType.name());
      if (!dataType.nullable) {
        statement.append(" NOT NULL");
      }
      statement.append(",");
    }
    statement.deleteCharAt(statement.length() - 1);
    statement.append(")");

    return statement.toString();
  }

  public static String insertIntoTable(Object o) {
    TableInfo tableInfo = TableHelper.from(o.getClass());
    StringBuilder statement = new StringBuilder();
    statement.append("INSERT INTO ").append(tableInfo.tableName).append(" ");
    statement.append("VALUES(");

    if (tableInfo.containID) {
      DatabaseDataType primaryDataType = SQLTypeParser.getDataType(tableInfo.primaryField);
      switch (primaryDataType) {
        case INTEGER:
          statement.append("NULL,");
          break;
        default:
          try {
            statement
              .append(ValueHelper.valueToString(primaryDataType, tableInfo.primaryField, o))
              .append(",");
          } catch (IllegalAccessException ignored) {
          }
          break;
      }

    } else {
      statement.append("NULL,");
    }

    for (Field field : tableInfo.fieldToDataTypeMap.keySet()) {
      DatabaseDataType dataType = tableInfo.fieldToDataTypeMap.get(field);
      try {
        statement.append(ValueHelper.valueToString(dataType, field, o)).append(",");
      } catch (IllegalAccessException e) {
      }
    }
    statement.deleteCharAt(statement.length() - 1);
    statement.append(")");

    return statement.toString();

  }

  public static String findByWhere(TableInfo tableInfo, String where) {
    StringBuilder statement = new StringBuilder("SELECT * FROM ");
    statement
      .append(tableInfo.tableName)
      .append(" ")
      .append("WHERE ")
      .append(where);

    return statement.toString();
  }


  public static String deleteByWhere(TableInfo tableInfo, String where) {
    StringBuilder statement = new StringBuilder("DELETE FROM ");
    statement
      .append(tableInfo.tableName)
      .append(" ")
      .append("WHERE ")
      .append(where);

    return statement.toString();
  }

  public static String updateByWhere(TableInfo tableInfo, Object bean, String where) {
    StringBuilder builder = new StringBuilder("UPDATE ");

    builder.append(tableInfo.tableName).append(" SET ");

    for (Field f : tableInfo.fieldToDataTypeMap.keySet()) {

      try {
        builder.append(f.getName())
          .append(" = ")
          .append(ValueHelper.valueToString(
            SQLTypeParser.getDataType(f.getType()),
            f.get(bean))).append(",");
      } catch (Throwable ignored) {
      }
    }

    builder.deleteCharAt(builder.length() - 1);

    builder.append(" WHERE ");
    builder.append(where);
    return builder.toString();
  }

  public static String selectTable(String tableName) {
    return "SELECT * FROM " + tableName;
  }

}
