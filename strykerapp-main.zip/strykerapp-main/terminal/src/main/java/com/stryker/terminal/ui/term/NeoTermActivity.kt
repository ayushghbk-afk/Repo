package com.stryker.terminal.ui.term

import android.Manifest
import android.annotation.SuppressLint
import android.content.*
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.ImageButton
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.OnApplyWindowInsetsListener
import androidx.core.view.ViewCompat
import androidx.preference.PreferenceManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.stryker.terminal.App
import com.stryker.terminal.R
import com.stryker.terminal.backend.TerminalSession
import com.stryker.terminal.component.ComponentManager
import com.stryker.terminal.component.config.NeoPreference
import com.stryker.terminal.component.config.NeoTermPath
import com.stryker.terminal.component.profile.ProfileComponent
import com.stryker.terminal.component.session.ShellParameter
import com.stryker.terminal.component.session.ShellProfile
import com.stryker.terminal.component.session.XSession
import com.stryker.terminal.frontend.floating.TerminalDialog
import com.stryker.terminal.frontend.session.terminal.*
import com.stryker.terminal.frontend.session.view.TerminalViewClient
import com.stryker.terminal.services.NeoTermService
import com.stryker.terminal.ui.other.SettingsActivity
import com.stryker.terminal.ui.other.WirelessDialogs
import com.stryker.terminal.utils.FullScreenHelper
import com.stryker.terminal.utils.NeoPermission
import com.stryker.terminal.utils.RangedInt
import de.mrapp.android.tabswitcher.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode


class NeoTermActivity : AppCompatActivity(), ServiceConnection, SharedPreferences.OnSharedPreferenceChangeListener {
  companion object {
    const val KEY_NO_RESTORE = "no_restore"
    const val REQUEST_SETUP = 22313
    const val EXTRA_NEW_SESSION = "com.stryker.terminal.NEW_SESSION"
  }

  lateinit var tabSwitcher: TabSwitcher
  private lateinit var fullScreenHelper: FullScreenHelper
  lateinit var toolbar: Toolbar

  var addSessionListener = createAddSessionListener()
  private var termService: NeoTermService? = null

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    App.get().ensureInitialized()

    val fullscreen = NeoPreference.isFullScreenEnabled()
    if (fullscreen) {
      window.setFlags(
        WindowManager.LayoutParams.FLAG_FULLSCREEN,
        WindowManager.LayoutParams.FLAG_FULLSCREEN,
      )
    }

    setContentView(R.layout.ui_main)

    toolbar = findViewById(R.id.terminal_toolbar)
    setSupportActionBar(toolbar)

    fullScreenHelper = FullScreenHelper.injectActivity(this, fullscreen, peekRecreating())
    fullScreenHelper.setKeyBoardListener(
      object : FullScreenHelper.KeyBoardListener {
        override fun onKeyboardChange(isShow: Boolean, keyboardHeight: Int) {
          if (tabSwitcher.selectedTab is TermTab) {
            val tab = tabSwitcher.selectedTab as TermTab
            toggleToolbar(tab.toolbar, !isShow)

            update_colors()
          }
        }
      },
    )

    tabSwitcher = findViewById(R.id.tab_switcher)
    tabSwitcher.decorator = NeoTabDecorator(this)
    ViewCompat.setOnApplyWindowInsetsListener(tabSwitcher, createWindowInsetsListener())
    tabSwitcher.showToolbars(false)

    val serviceIntent = Intent(this, NeoTermService::class.java)
    startService(serviceIntent)
    bindService(serviceIntent, this, 0)
  }

  private fun wantsFreshSession(): Boolean =
    intent?.getBooleanExtra(EXTRA_NEW_SESSION, false) == true

  override fun onNewIntent(newIntent: Intent?) {
    super.onNewIntent(newIntent)
    setIntent(newIntent)
    if (newIntent?.getBooleanExtra(EXTRA_NEW_SESSION, false) != true) return
    if (termService == null) return
    addNewSession(null, false, createRevealAnimation())
  }

  private fun toggleToolbar(toolbar: Toolbar?, visible: Boolean) {
    if (toolbar == null) {
      return
    }

    if (NeoPreference.isFullScreenEnabled()
      || NeoPreference.isHideToolbarEnabled()
    ) {
      val toolbarHeight = toolbar.height.toFloat()
      val translationY = if (visible) 0.toFloat() else -toolbarHeight
      if (visible) {
        toolbar.visibility = View.VISIBLE
        toolbar.animate()
          .translationY(translationY)
          .start()
      } else {
        toolbar.animate()
          .translationY(translationY)
          .withEndAction {
            toolbar.visibility = View.GONE
          }
          .start()
      }
    }
  }

  override fun onCreateOptionsMenu(menu: Menu?): Boolean {
    menuInflater.inflate(R.menu.menu_main, menu)

    TabSwitcher.setupWithMenu(
      tabSwitcher, toolbar.menu,
    ) {
      if (!tabSwitcher.isSwitcherShown) {
        val imm = this@NeoTermActivity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (imm.isActive && tabSwitcher.selectedTab is TermTab) {
          val tab = tabSwitcher.selectedTab as TermTab
          tab.requireHideIme()
        }
        toggleSwitcher(showSwitcher = true, easterEgg = true)
      } else {
        toggleSwitcher(showSwitcher = false, easterEgg = true)
      }
    }
    return true
  }

  override fun onOptionsItemSelected(item: MenuItem): Boolean {
    return when (item.itemId) {
      R.id.menu_item_settings -> {
        startActivity(Intent(this, SettingsActivity::class.java))
        true
      }
      R.id.menu_item_new_session -> {
        addNewStrykerSession("Stryker")
        true
      }
      R.id.menu_item_new_root_session -> {
        addNewRootSession("Android SU")
        true
      }
      R.id.get_interfaces -> {
        WirelessDialogs.showInterfaces(this)
        true
      }
      R.id.get_usb_devices -> {
        WirelessDialogs.showUsbDevices(this)
        true
      }
      else -> item.let { super.onOptionsItemSelected(it) }
    }
  }

  override fun onPause() {
    super.onPause()
    val tab = tabSwitcher.selectedTab as NeoTab?
    if (tab != null) {
      tab.onStart()
    }
  }

  override fun onResume() {
    super.onResume()

    PreferenceManager.getDefaultSharedPreferences(this)
      .registerOnSharedPreferenceChangeListener(this)
    tabSwitcher.addListener(
      object : TabSwitcherListener {
        override fun onSwitcherShown(tabSwitcher: TabSwitcher) {
          toolbar.setNavigationIcon(R.drawable.ic_add_box_white_24dp)
          toolbar.setNavigationOnClickListener(addSessionListener)
          toolbar.setBackgroundResource(android.R.color.transparent)
          toolbar.animate().alpha(0f).setDuration(300).withEndAction {
            toolbar.alpha = 1f
          }.start()
        }

        override fun onSwitcherHidden(tabSwitcher: TabSwitcher) {
          toolbar.navigationIcon = null
          toolbar.setNavigationOnClickListener(null)
          toolbar.setBackgroundResource(R.color.colorPrimary)
        }

        override fun onSelectionChanged(tabSwitcher: TabSwitcher, selectedTabIndex: Int, selectedTab: Tab?) {
          if (selectedTab is TermTab && selectedTab.termData.termSession != null) {
            NeoPreference.storeCurrentSession(selectedTab.termData.termSession!!)
          }
        }

        override fun onTabAdded(tabSwitcher: TabSwitcher, index: Int, tab: Tab, animation: Animation) {
          update_colors()
        }

        override fun onTabRemoved(tabSwitcher: TabSwitcher, index: Int, tab: Tab, animation: Animation) {
          if (tab is TermTab) {
            SessionRemover.removeSession(termService, tab)
          } else if (tab is XSessionTab) {
            SessionRemover.removeXSession(termService, tab)
          }
        }

        override fun onAllTabsRemoved(tabSwitcher: TabSwitcher, tabs: Array<out Tab>, animation: Animation) {
        }
      },
    )
    val tab = tabSwitcher.selectedTab as NeoTab?
    tab?.onResume()

  }

  override fun onStart() {
    super.onStart()
    EventBus.getDefault().register(this)
    val tab = tabSwitcher.selectedTab as NeoTab?
    tab?.onStart()
  }

  override fun onStop() {
    super.onStop()
    forEachTab<TermTab> { it.resetAutoCompleteStatus() }
    val tab = tabSwitcher.selectedTab as NeoTab?
    tab?.onStop()
    EventBus.getDefault().unregister(this)
  }

  override fun onDestroy() {
    super.onDestroy()
    val tab = tabSwitcher.selectedTab as NeoTab?
    tab?.onDestroy()
    PreferenceManager.getDefaultSharedPreferences(this)
      .unregisterOnSharedPreferenceChangeListener(this)

    if (termService != null) {
      if (termService!!.sessions.isEmpty()) {
        termService!!.stopSelf()
      }
      termService = null
    }
    unbindService(this)
  }

  override fun onWindowFocusChanged(hasFocus: Boolean) {
    super.onWindowFocusChanged(hasFocus)
    val tab = tabSwitcher.selectedTab as NeoTab?
    tab?.onWindowFocusChanged(hasFocus)
  }

  override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
    when (keyCode) {
      KeyEvent.KEYCODE_BACK -> {
        if (event?.action == KeyEvent.ACTION_DOWN && tabSwitcher.isSwitcherShown && tabSwitcher.count > 0) {
          toggleSwitcher(showSwitcher = false, easterEgg = false)
          return true
        }
      }
      KeyEvent.KEYCODE_MENU -> {
        if (toolbar.isOverflowMenuShowing) {
          toolbar.hideOverflowMenu()
        } else {
          toolbar.showOverflowMenu()
        }
        return true
      }
    }
    return super.onKeyDown(keyCode, event)
  }

  override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
    if (key == getString(R.string.key_ui_fullscreen)) {
      setFullScreenMode(NeoPreference.isFullScreenEnabled())
    } else if (key == getString(R.string.key_customization_color_scheme)) {
      if (tabSwitcher.count > 0) {
        val tab = tabSwitcher.selectedTab
        if (tab is TermTab) {
          tab.updateColorScheme()
        }
      }
    }
  }

  override fun onServiceDisconnected(name: ComponentName?) {
    if (termService != null) {
      finish()
    }
  }

  @RequiresApi(Build.VERSION_CODES.P)
  override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
    termService = (service as NeoTermService.NeoTermBinder).service
    if (termService == null) {
      finish()
      return
    }

    if (!isRecreating()) {
      enterMain()
      update_colors()
    }
  }

  override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    when (requestCode) {
      REQUEST_SETUP -> {
        when (resultCode) {
          RESULT_OK -> enterMain()
          RESULT_CANCELED -> {
            setSystemShellMode(true)
            forceAddSystemSession()
          }
        }
      }
    }
    super.onActivityResult(requestCode, resultCode, data)
  }

  override fun onConfigurationChanged(newConfig: Configuration) {
    super.onConfigurationChanged(newConfig)
    if (newConfig == null) {
      return
    }

    forEachTab<NeoTab> {
      it.onConfigurationChanged(newConfig)
      if (it is TermTab) {
        it.resetStatus()
      }
    }
  }

  private fun forceAddSystemSession() {
    if (!tabSwitcher.isSwitcherShown) {
      toggleSwitcher(showSwitcher = true, easterEgg = false)
    }

    addNewSession(null, true, createRevealAnimation())
  }

  private fun enterMain() {
    setSystemShellMode(false)

    if (!termService!!.sessions.isEmpty()) {
      val lastSession = getStoredCurrentSessionOrLast()

      for (session in termService!!.sessions) {
        addNewSessionFromExisting(session)
      }

      for (session in termService!!.xSessions) {
        addXSession(session)
      }

      if (intent?.action == Intent.ACTION_RUN || wantsFreshSession()) {
        addNewSession(
          null,
          false, createRevealAnimation(),
        )
      } else {
        switchToSession(lastSession)
      }

    } else {
      toggleSwitcher(showSwitcher = true, easterEgg = false)
      addNewSession(null, false, createRevealAnimation())
    }
  }

  override fun recreate() {
    NeoPreference.store(KEY_NO_RESTORE, true)
    saveCurrentStatus()
    super.recreate()
  }

  private fun isRecreating(): Boolean {
    val result = peekRecreating()
    if (result) {
      NeoPreference.store(KEY_NO_RESTORE, !result)
    }
    return result
  }

  private fun saveCurrentStatus() {
    setSystemShellMode(getSystemShellMode())
  }

  private fun peekRecreating(): Boolean {
    return NeoPreference.loadBoolean(KEY_NO_RESTORE, false)
  }

  private fun setFullScreenMode(fullScreen: Boolean) {
    fullScreenHelper.fullScreen = fullScreen
    if (tabSwitcher.selectedTab is TermTab) {
      val tab = tabSwitcher.selectedTab as TermTab
      tab.requireHideIme()
      tab.onFullScreenModeChanged(fullScreen)
    }
    NeoPreference.store(R.string.key_ui_fullscreen, fullScreen)
    this@NeoTermActivity.recreate()
  }

  private fun showProfileDialog() {
    val profileComponent = ComponentManager.getComponent<ProfileComponent>()
    val profiles = profileComponent.getProfiles(ShellProfile.PROFILE_META_NAME)
    val profilesShell = profiles.filterIsInstance<ShellProfile>()

    if (profiles.isEmpty()) {
      MaterialAlertDialogBuilder(this)
        .setTitle(R.string.error)
        .setMessage(R.string.no_profile_available)
        .setPositiveButton(android.R.string.yes, null)
        .show()
      return
    }

    MaterialAlertDialogBuilder(this)
      .setTitle(R.string.new_session_with_profile)
      .setItems(
        profiles.map { it.profileName }.toTypedArray(),
        { dialog, which ->
          val selectedProfile = profilesShell[which]
          addNewSessionWithProfile(selectedProfile)
        },
      )
      .setPositiveButton(android.R.string.no, null)
      .show()
  }

  private fun addNewSession() {
    addNewStrykerSession("Stryker")
  }

  private fun addNewSession(sessionName: String?, systemShell: Boolean, animation: Animation) {
    addNewStrykerSession("Stryker")
  }

  private fun addNewSessionWithProfile(profile: ShellProfile) {
    if (!tabSwitcher.isSwitcherShown) {
      toggleSwitcher(showSwitcher = true, easterEgg = false)
    }
    addNewSessionWithProfile(
      null, getSystemShellMode(),
      createRevealAnimation(), profile,
    )
  }

  private fun addNewSessionWithProfile(
    sessionName: String?, systemShell: Boolean,
    animation: Animation, profile: ShellProfile,
  ) {
    val sessionCallback = TermSessionCallback()
    val viewClient = TermViewClient(this)

    val parameter = ShellParameter()
      .callback(sessionCallback)
      .systemShell(systemShell)
      .profile(profile)
    val session = termService!!.createTermSession(parameter)

    session.mSessionName = sessionName ?: generateSessionName("Stryker")

    val tab = createTab(session.mSessionName) as TermTab
    tab.termData.initializeSessionWith(session, sessionCallback, viewClient)

    addNewTab(tab, animation)
    switchToSession(tab)
  }

  @SuppressLint("SdCardPath")
  private fun addNewAndroidSession(sessionName: String?) {
    val sessionCallback = TermSessionCallback()
    val viewClient = TermViewClient(this)

    val parameter = ShellParameter()
      .callback(sessionCallback)
      .executablePath("${NeoTermPath.BIN_PATH}/bash")
      .systemShell(true)

    val session = termService!!.createTermSession(parameter)

    session.mSessionName = sessionName ?: generateSessionName("Android")

    val tab = createTab(session.mSessionName) as TermTab
    tab.termData.initializeSessionWith(session, sessionCallback, viewClient)

    addNewTab(tab, createRevealAnimation())
    switchToSession(tab)
  }

  private fun addNewStrykerSession(sessionName: String?) {
    val sessionCallback = TermSessionCallback()
    val viewClient = TermViewClient(this)

    val rootless = java.io.File(filesDir, "rootless/.active").exists()
    val parameter = ShellParameter().callback(sessionCallback)
    if (rootless) {
      parameter.executablePath("pty:127.0.0.1:1051")
    } else {
      parameter
        .executablePath("${NeoTermPath.BIN_PATH}/stryker-ch")
        .initialCommand("clear")
    }
    val session = termService!!.createTermSession(parameter)

    session.mSessionName = sessionName ?: generateSessionName("Stryker")

    val tab = createTab(session.mSessionName) as TermTab
    tab.termData.initializeSessionWith(session, sessionCallback, viewClient)

    addNewTab(tab, createRevealAnimation())
    switchToSession(tab)
  }

  @SuppressLint("SdCardPath")
  private fun addNewRootSession(sessionName: String?) {
    val sessionCallback = TermSessionCallback()
    val viewClient = TermViewClient(this)

    val parameter = ShellParameter()
      .callback(sessionCallback)
      .executablePath("${NeoTermPath.BIN_PATH}/android-su")
      .systemShell(true)
      .initialCommand("clear")

    val session = termService!!.createTermSession(parameter)
    generateSessionName("Android")

    session.mSessionName = sessionName ?: generateSessionName("ANDROID SU")

    val tab = createTab(session.mSessionName) as TermTab
    tab.termData.initializeSessionWith(session, sessionCallback, viewClient)

    addNewTab(tab, createRevealAnimation())
    switchToSession(tab)
  }

  private fun addNewSessionFromExisting(session: TerminalSession?) {
    if (session == null) {
      return
    }

    val tabCount = tabSwitcher.count
    (0..(tabCount - 1))
      .map { tabSwitcher.getTab(it) }
      .filter { it is TermTab && it.termData.termSession == session }
      .forEach { return }

    val sessionCallback = session.sessionChangedCallback as TermSessionCallback
    val viewClient = TermViewClient(this)

    val tab = createTab(session.title) as TermTab
    tab.termData.initializeSessionWith(session, sessionCallback, viewClient)

    addNewTab(tab, createRevealAnimation())
    switchToSession(tab)
  }

  private fun addXSession(session: XSession?) {
    if (session == null) {
      return
    }

    val tabCount = tabSwitcher.count
    (0..(tabCount - 1))
      .map { tabSwitcher.getTab(it) }
      .filter { it is XSessionTab && it.session == session }
      .forEach { return }

    val tab = createXTab(session.mSessionName) as XSessionTab

    addNewTab(tab, createRevealAnimation())
    switchToSession(tab)
  }

  private fun generateSessionName(prefix: String): String {
    return "$prefix #${termService!!.sessions.size}"
  }

  private fun generateXSessionName(prefix: String): String {
    return "$prefix #${termService!!.xSessions.size}"
  }

  private fun switchToSession(session: TerminalSession?) {
    if (session == null) {
      return
    }

    for (i in 0 until tabSwitcher.count) {
      val tab = tabSwitcher.getTab(i)
      if (tab is TermTab && tab.termData.termSession == session) {
        switchToSession(tab)
        break
      }
    }
  }

  private fun switchToSession(tab: Tab?) {
    if (tab == null) {
      return
    }
    tabSwitcher.selectTab(tab)

  }

  private fun addNewTab(tab: Tab, animation: Animation) {
    tabSwitcher.addTab(tab, 0, animation)
  }

  private fun getStoredCurrentSessionOrLast(): TerminalSession? {
    val stored = NeoPreference.getCurrentSession(termService)
    if (stored != null) return stored
    val numberOfSessions = termService!!.sessions.size
    if (numberOfSessions == 0) return null
    return termService!!.sessions[numberOfSessions - 1]
  }

  private fun createAddSessionListener(): View.OnClickListener {
    return View.OnClickListener {
      addNewSession()
    }
  }

  private fun createTab(tabTitle: String?): Tab {
    return postTabCreated(TermTab(tabTitle ?: "Android"))
  }

  private fun createXTab(tabTitle: String?): Tab {
    return postTabCreated(XSessionTab(tabTitle ?: "Stryker"))
  }

  private fun <T : NeoTab> postTabCreated(tab: T): T {
    tab.parameters = Bundle()

    tab.setBackgroundColor(ContextCompat.getColor(this, R.color.tab_background_color))
    tab.setTitleTextColor(ContextCompat.getColor(this, R.color.tab_title_text_color))
    return tab
  }

  private fun createRevealAnimation(): Animation {
    var x = 0f
    var y = 0f
    val view = getNavigationMenuItem()

    if (view != null) {
      val location = IntArray(2)
      view.getLocationInWindow(location)
      x = location[0] + view.width / 2f
      y = location[1] + view.height / 2f
    }

    return RevealAnimation.Builder().setX(x).setY(y).create()
  }

  private fun getNavigationMenuItem(): View? {
    val toolbars = tabSwitcher.toolbars

    if (toolbars != null) {
      val toolbar = if (toolbars.size > 1) toolbars[1] else toolbars[0]
      val size = toolbar.childCount

      (0 until size)
        .map { toolbar.getChildAt(it) }
        .filterIsInstance(ImageButton::class.java)
        .forEach { return it }
    }

    return null
  }

  private fun createWindowInsetsListener(): OnApplyWindowInsetsListener {
    return OnApplyWindowInsetsListener { _, insets ->
      tabSwitcher.setPadding(
        insets.systemWindowInsetLeft,
        insets.systemWindowInsetTop, insets.systemWindowInsetRight,
        insets.systemWindowInsetBottom,
      )
      insets
    }
  }

  private fun toggleSwitcher(showSwitcher: Boolean, easterEgg: Boolean) {
    if (tabSwitcher.count == 0 && easterEgg) {
      App.get().easterEgg(this, "Stop! You don't know what you are doing!")
      return
    }

    if (showSwitcher) {
      tabSwitcher.showSwitcher()
    } else {
      tabSwitcher.hideSwitcher()
    }
  }

  private fun setSystemShellMode(systemShell: Boolean) {
    NeoPreference.store(NeoPreference.KEY_SYSTEM_SHELL, systemShell)
  }

  private fun getSystemShellMode(): Boolean {
    return NeoPreference.loadBoolean(NeoPreference.KEY_SYSTEM_SHELL, true)
  }

  private inline fun <reified T> forEachTab(callback: (T) -> Unit) {
    (0 until tabSwitcher.count)
      .map { tabSwitcher.getTab(it) }
      .filterIsInstance(T::class.java)
      .forEach(callback)
  }

  @Suppress("unused")
  @Subscribe(threadMode = ThreadMode.MAIN)
  fun onTabCloseEvent(tabCloseEvent: TabCloseEvent) {
    val tab = tabCloseEvent.termTab
    toggleSwitcher(showSwitcher = true, easterEgg = false)
    tabSwitcher.removeTab(tab)

    if (tabSwitcher.count > 1) {
      var index = tabSwitcher.indexOf(tab)
      if (NeoPreference.isNextTabEnabled()) {
        if (--index < 0) index = tabSwitcher.count - 1
      } else {
        if (++index >= tabSwitcher.count) index = 0
      }
      switchToSession(tabSwitcher.getTab(index))
    }
  }

  @Suppress("unused", "UNUSED_PARAMETER")
  @Subscribe(threadMode = ThreadMode.MAIN)
  fun onToggleFullScreenEvent(toggleFullScreenEvent: ToggleFullScreenEvent) {
    val fullScreen = fullScreenHelper.fullScreen
    setFullScreenMode(!fullScreen)
  }

  @Suppress("unused", "UNUSED_PARAMETER")
  @Subscribe(threadMode = ThreadMode.MAIN)
  fun onToggleImeEvent(toggleImeEvent: ToggleImeEvent) {
    if (!tabSwitcher.isSwitcherShown) {
      val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
      imm.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, 0)
    }
  }

  @Subscribe(threadMode = ThreadMode.MAIN)
  fun onTitleChangedEvent(titleChangedEvent: TitleChangedEvent) {
    if (!tabSwitcher.isSwitcherShown) {
      toolbar.title = titleChangedEvent.title
    }
  }

  @Suppress("unused", "UNUSED_PARAMETER")
  @Subscribe(threadMode = ThreadMode.MAIN)
  fun onCreateNewSessionEvent(createNewSessionEvent: CreateNewSessionEvent) {
    addNewSession()
  }

  @Suppress("unused", "UNUSED_PARAMETER")
  @Subscribe(threadMode = ThreadMode.MAIN)
  fun onSwitchSessionEvent(switchSessionEvent: SwitchSessionEvent) {
    if (tabSwitcher.count < 2) {
      return
    }

    val rangedInt = RangedInt(tabSwitcher.selectedTabIndex, (0 until tabSwitcher.count))
    val nextIndex = if (switchSessionEvent.toNext) rangedInt.inc() else rangedInt.dec()
    if (!tabSwitcher.isSwitcherShown) {
      tabSwitcher.showSwitcher()
    }
    switchToSession(tabSwitcher.getTab(nextIndex))
  }

  @Suppress("unused", "UNUSED_PARAMETER")
  @Subscribe(threadMode = ThreadMode.MAIN)
  fun onSwitchIndexedSessionEvent(switchIndexedSessionEvent: SwitchIndexedSessionEvent) {
    val nextIndex = switchIndexedSessionEvent.index - 1
    if (nextIndex in (0 until tabSwitcher.count) && nextIndex != tabSwitcher.selectedTabIndex) {
      switchToSession(tabSwitcher.getTab(nextIndex))
    }
  }

  fun update_colors() {
    Handler().postDelayed(
      {

        if (tabSwitcher.count > 0) {
          val tab = tabSwitcher.selectedTab
          if (tab is TermTab) {
            tab.updateColorScheme()
          }
        }

      },
      100,
    )
  }

}
