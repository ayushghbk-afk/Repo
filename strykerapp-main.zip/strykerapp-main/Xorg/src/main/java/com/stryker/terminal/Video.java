/*
Simple DirectMedia Layer
Java source code (C) 2009-2014 Sergii Pylypenko

This software is provided 'as-is', without any express or implied
warranty.  In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required. 
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/

package com.stryker.terminal;

import android.content.Context;
import android.content.Intent;
import android.hardware.input.InputManager;
import android.net.Uri;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.*;
import android.widget.Toast;
import com.stryker.terminal.xorg.NeoXorgViewClient;

import javax.microedition.khronos.egl.*;
import javax.microedition.khronos.opengles.GL10;
import java.lang.reflect.Method;


class Mouse {
  public static final int LEFT_CLICK_NORMAL = 0;
  public static final int LEFT_CLICK_NEAR_CURSOR = 1;
  public static final int LEFT_CLICK_WITH_MULTITOUCH = 2;
  public static final int LEFT_CLICK_WITH_PRESSURE = 3;
  public static final int LEFT_CLICK_WITH_KEY = 4;
  public static final int LEFT_CLICK_WITH_TIMEOUT = 5;
  public static final int LEFT_CLICK_WITH_TAP = 6;
  public static final int LEFT_CLICK_WITH_TAP_OR_TIMEOUT = 7;

  public static final int RIGHT_CLICK_NONE = 0;
  public static final int RIGHT_CLICK_WITH_MULTITOUCH = 1;
  public static final int RIGHT_CLICK_WITH_PRESSURE = 2;
  public static final int RIGHT_CLICK_WITH_KEY = 3;
  public static final int RIGHT_CLICK_WITH_TIMEOUT = 4;

  public static final int SDL_FINGER_DOWN = 0;
  public static final int SDL_FINGER_UP = 1;
  public static final int SDL_FINGER_MOVE = 2;
  public static final int SDL_FINGER_HOVER = 3;

  public static final int ZOOM_NONE = 0;
  public static final int ZOOM_MAGNIFIER = 1;

  public static final int MOUSE_HW_INPUT_FINGER = 0;
  public static final int MOUSE_HW_INPUT_STYLUS = 1;
  public static final int MOUSE_HW_INPUT_MOUSE = 2;

  public static final int MAX_HOVER_DISTANCE = 1024;
  public static final int HOVER_REDRAW_SCREEN = 1024 * 10;
  public static final float MAX_PRESSURE = 1024.0f;
}

abstract class DifferentTouchInput {
  public abstract void process(final MotionEvent event);

  public abstract void processGenericEvent(final MotionEvent event);

  public static int ExternalMouseDetected = Mouse.MOUSE_HW_INPUT_FINGER;

  public static DifferentTouchInput touchInput = getInstance();

  public static DifferentTouchInput getInstance() {
    boolean multiTouchAvailable1 = false;
    boolean multiTouchAvailable2 = false;
    Method methods[] = MotionEvent.class.getDeclaredMethods();
    for (Method m : methods) {
      if (m.getName().equals("getPointerCount"))
        multiTouchAvailable1 = true;
      if (m.getName().equals("getPointerId"))
        multiTouchAvailable2 = true;
    }
    try {
      Log.i("SDL", "Device: " + Build.DEVICE);
      Log.i("SDL", "Device name: " + Build.DISPLAY);
      Log.i("SDL", "Device model: " + Build.MODEL);
      Log.i("SDL", "Device board: " + Build.BOARD);
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
        return AutoDetectTouchInput.Holder.sInstance;
      }
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD)
        return GingerbreadTouchInput.Holder.sInstance;
      if (multiTouchAvailable1 && multiTouchAvailable2)
        return MultiTouchInput.Holder.sInstance;
      else
        return SingleTouchInput.Holder.sInstance;
    } catch (Exception e) {
      try {
        if (multiTouchAvailable1 && multiTouchAvailable2)
          return MultiTouchInput.Holder.sInstance;
        else
          return SingleTouchInput.Holder.sInstance;
      } catch (Exception ee) {
        return SingleTouchInput.Holder.sInstance;
      }
    }
  }

  private static class SingleTouchInput extends DifferentTouchInput {
    private static class Holder {
      private static final SingleTouchInput sInstance = new SingleTouchInput();
    }

    @Override
    public void processGenericEvent(final MotionEvent event) {
      process(event);
    }

    public void process(final MotionEvent event) {
      int action = -1;
      if (event.getAction() == MotionEvent.ACTION_DOWN)
        action = Mouse.SDL_FINGER_DOWN;
      if (event.getAction() == MotionEvent.ACTION_UP)
        action = Mouse.SDL_FINGER_UP;
      if (event.getAction() == MotionEvent.ACTION_MOVE)
        action = Mouse.SDL_FINGER_MOVE;
      if (action >= 0)
        DemoGLSurfaceView.nativeMotionEvent((int) event.getX(), (int) event.getY(), action, 0,
          (int) (event.getPressure() * Mouse.MAX_PRESSURE),
          (int) (event.getSize() * Mouse.MAX_PRESSURE));
    }
  }

  private static class MultiTouchInput extends DifferentTouchInput {
    public static final int TOUCH_EVENTS_MAX = 16;

    private class touchEvent {
      public boolean down = false;
      public int x = 0;
      public int y = 0;
      public int pressure = 0;
      public int size = 0;
    }

    protected touchEvent touchEvents[];

    MultiTouchInput() {
      touchEvents = new touchEvent[TOUCH_EVENTS_MAX];
      for (int i = 0; i < TOUCH_EVENTS_MAX; i++)
        touchEvents[i] = new touchEvent();
    }

    private static class Holder {
      private static final MultiTouchInput sInstance = new MultiTouchInput();
    }

    public void processGenericEvent(final MotionEvent event) {
      process(event);
    }

    public void process(final MotionEvent event) {
      int action = -1;

      if ((event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_UP ||
        (event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_CANCEL) {
        action = Mouse.SDL_FINGER_UP;
        for (int i = 0; i < TOUCH_EVENTS_MAX; i++) {
          if (touchEvents[i].down) {
            touchEvents[i].down = false;
            DemoGLSurfaceView.nativeMotionEvent(touchEvents[i].x, touchEvents[i].y, action, i, touchEvents[i].pressure, touchEvents[i].size);
          }
        }
      }
      if ((event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_DOWN) {
        action = Mouse.SDL_FINGER_DOWN;
        for (int i = 0; i < event.getPointerCount(); i++) {
          int id = event.getPointerId(i);
          if (id >= TOUCH_EVENTS_MAX)
            id = TOUCH_EVENTS_MAX - 1;
          touchEvents[id].down = true;
          touchEvents[id].x = (int) event.getX(i);
          touchEvents[id].y = (int) event.getY(i);
          touchEvents[id].pressure = (int) (event.getPressure(i) * Mouse.MAX_PRESSURE);
          touchEvents[id].size = (int) (event.getSize(i) * Mouse.MAX_PRESSURE);
          DemoGLSurfaceView.nativeMotionEvent(touchEvents[id].x, touchEvents[id].y, action, id, touchEvents[id].pressure, touchEvents[id].size);
        }
      }
      if ((event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_MOVE ||
        (event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_POINTER_DOWN ||
        (event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_POINTER_UP) {
        int pointerReleased = -1;
        if ((event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_POINTER_UP)
          pointerReleased = (event.getAction() & MotionEvent.ACTION_POINTER_INDEX_MASK) >> MotionEvent.ACTION_POINTER_INDEX_SHIFT;

        for (int id = 0; id < TOUCH_EVENTS_MAX; id++) {
          int ii;
          for (ii = 0; ii < event.getPointerCount(); ii++) {
            if (id == event.getPointerId(ii))
              break;
          }
          if (ii >= event.getPointerCount()) {
            if (touchEvents[id].down) {
              action = Mouse.SDL_FINGER_UP;
              touchEvents[id].down = false;
              DemoGLSurfaceView.nativeMotionEvent(touchEvents[id].x, touchEvents[id].y, action, id, touchEvents[id].pressure, touchEvents[id].size);
            }
          } else {
            if (pointerReleased == id && touchEvents[pointerReleased].down) {
              action = Mouse.SDL_FINGER_UP;
              touchEvents[id].down = false;
            } else if (touchEvents[id].down) {
              action = Mouse.SDL_FINGER_MOVE;
            } else {
              action = Mouse.SDL_FINGER_DOWN;
              touchEvents[id].down = true;
            }
            touchEvents[id].x = (int) event.getX(ii);
            touchEvents[id].y = (int) event.getY(ii);
            touchEvents[id].pressure = (int) (event.getPressure(ii) * Mouse.MAX_PRESSURE);
            touchEvents[id].size = (int) (event.getSize(ii) * Mouse.MAX_PRESSURE);
            DemoGLSurfaceView.nativeMotionEvent(touchEvents[id].x, touchEvents[id].y, action, id, touchEvents[id].pressure, touchEvents[id].size);
          }
        }
      }
    }
  }

  private static class GingerbreadTouchInput extends MultiTouchInput {
    private static class Holder {
      private static final GingerbreadTouchInput sInstance = new GingerbreadTouchInput();
    }

    GingerbreadTouchInput() {
      super();
    }

    public void process(final MotionEvent event) {
      int hwMouseEvent = ((event.getSource() & InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE || Globals.ForceHardwareMouse) ? Mouse.MOUSE_HW_INPUT_MOUSE :
        ((event.getSource() & InputDevice.SOURCE_STYLUS) == InputDevice.SOURCE_STYLUS) ? Mouse.MOUSE_HW_INPUT_STYLUS :
          Mouse.MOUSE_HW_INPUT_FINGER;
      if (ExternalMouseDetected != hwMouseEvent) {
        ExternalMouseDetected = hwMouseEvent;
        DemoGLSurfaceView.nativeHardwareMouseDetected(hwMouseEvent);
      }
      super.process(event);
      if (!Globals.FingerHover && ExternalMouseDetected == Mouse.MOUSE_HW_INPUT_FINGER)
        return;
      if ((event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_HOVER_MOVE)
      {
        int action;
        if (touchEvents[0].down)
          action = Mouse.SDL_FINGER_UP;
        else
          action = Mouse.SDL_FINGER_HOVER;
        touchEvents[0].down = false;
        touchEvents[0].x = (int) event.getX();
        touchEvents[0].y = (int) event.getY();
        touchEvents[0].pressure = Mouse.MAX_HOVER_DISTANCE;
        touchEvents[0].size = 0;
        InputDevice device = InputDevice.getDevice(event.getDeviceId());
        if (device != null && device.getMotionRange(MotionEvent.AXIS_DISTANCE) != null &&
          device.getMotionRange(MotionEvent.AXIS_DISTANCE).getRange() > 0.0f)
          touchEvents[0].pressure = (int) ((event.getAxisValue(MotionEvent.AXIS_DISTANCE) -
            device.getMotionRange(MotionEvent.AXIS_DISTANCE).getMin()) * Mouse.MAX_PRESSURE / device.getMotionRange(MotionEvent.AXIS_DISTANCE).getRange());
        DemoGLSurfaceView.nativeMotionEvent(touchEvents[0].x, touchEvents[0].y, action, 0, touchEvents[0].pressure, touchEvents[0].size);
      }
      if ((event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_HOVER_EXIT)
      {
        touchEvents[0].pressure = Mouse.HOVER_REDRAW_SCREEN;
        touchEvents[0].size = 0;
        DemoGLSurfaceView.nativeMotionEvent(touchEvents[0].x, touchEvents[0].y, Mouse.SDL_FINGER_HOVER, 0, touchEvents[0].pressure, touchEvents[0].size);
      }
    }

    public void processGenericEvent(final MotionEvent event) {
      process(event);
    }
  }

  private static class IcsTouchInput extends GingerbreadTouchInput {
    private static class Holder {
      private static final IcsTouchInput sInstance = new IcsTouchInput();
    }

    private int buttonState = 0;

    public void process(final MotionEvent event) {
      int buttonStateNew = event.getButtonState();
      if (buttonStateNew != buttonState) {
        for (int i = 1; i <= MotionEvent.BUTTON_FORWARD; i *= 2) {
          if ((buttonStateNew & i) != (buttonState & i))
            DemoGLSurfaceView.nativeMouseButtonsPressed(i, ((buttonStateNew & i) == 0) ? 0 : 1);
        }
        if ((buttonStateNew & MotionEvent.BUTTON_STYLUS_PRIMARY) != (buttonState & MotionEvent.BUTTON_STYLUS_PRIMARY))
          DemoGLSurfaceView.nativeMouseButtonsPressed(2, ((buttonStateNew & MotionEvent.BUTTON_STYLUS_PRIMARY) == 0) ? 0 : 1);
        if ((buttonStateNew & MotionEvent.BUTTON_STYLUS_SECONDARY) != (buttonState & MotionEvent.BUTTON_STYLUS_SECONDARY))
          DemoGLSurfaceView.nativeMouseButtonsPressed(4, ((buttonStateNew & MotionEvent.BUTTON_STYLUS_SECONDARY) == 0) ? 0 : 1);
        buttonState = buttonStateNew;
      }
      super.process(event);
    }

    public void processGenericEvent(final MotionEvent event) {
      if ((event.getSource() & InputDevice.SOURCE_CLASS_JOYSTICK) == InputDevice.SOURCE_CLASS_JOYSTICK) {
        DemoGLSurfaceView.nativeGamepadAnalogJoystickInput(
          event.getAxisValue(MotionEvent.AXIS_X), event.getAxisValue(MotionEvent.AXIS_Y),
          event.getAxisValue(MotionEvent.AXIS_Z), event.getAxisValue(MotionEvent.AXIS_RZ),
          event.getAxisValue(MotionEvent.AXIS_LTRIGGER), event.getAxisValue(MotionEvent.AXIS_RTRIGGER),
          event.getAxisValue(MotionEvent.AXIS_HAT_X), event.getAxisValue(MotionEvent.AXIS_HAT_Y),
          processGamepadDeviceId(event.getDevice()));
        return;
      }
      if (event.getAction() == MotionEvent.ACTION_SCROLL) {
        int scrollX = Math.round(event.getAxisValue(MotionEvent.AXIS_HSCROLL));
        int scrollY = Math.round(event.getAxisValue(MotionEvent.AXIS_VSCROLL));
        DemoGLSurfaceView.nativeMouseWheel(scrollX, scrollY);
        return;
      }
      super.processGenericEvent(event);
    }
  }

  private static class IcsTouchInputWithHistory extends IcsTouchInput {
    private static class Holder {
      private static final IcsTouchInputWithHistory sInstance = new IcsTouchInputWithHistory();
    }

    public void process(final MotionEvent event) {
      int ptr = 0;
      for (ptr = 0; ptr < TOUCH_EVENTS_MAX; ptr++) {
        if (touchEvents[ptr].down)
          break;
      }
      if (ptr >= TOUCH_EVENTS_MAX)
        ptr = 0;

      for (int i = 0; i < event.getHistorySize(); i++) {
        DemoGLSurfaceView.nativeMotionEvent((int) event.getHistoricalX(i), (int) event.getHistoricalY(i),
          Mouse.SDL_FINGER_MOVE, ptr, (int) (event.getHistoricalPressure(i) * Mouse.MAX_PRESSURE), (int) (event.getHistoricalSize(i) * Mouse.MAX_PRESSURE));
      }
      super.process(event);
    }
  }

  private static class CrappyMtkTabletWithBrokenTouchDrivers extends IcsTouchInput {
    private static class Holder {
      private static final CrappyMtkTabletWithBrokenTouchDrivers sInstance = new CrappyMtkTabletWithBrokenTouchDrivers();
    }

    public void process(final MotionEvent event) {
      if ((event.getAction() & MotionEvent.ACTION_MASK) != MotionEvent.ACTION_HOVER_MOVE &&
        (event.getAction() & MotionEvent.ACTION_MASK) != MotionEvent.ACTION_HOVER_EXIT)
        super.process(event);
    }

    public void processGenericEvent(final MotionEvent event) {
      if ((event.getAction() & MotionEvent.ACTION_MASK) != MotionEvent.ACTION_HOVER_MOVE &&
        (event.getAction() & MotionEvent.ACTION_MASK) != MotionEvent.ACTION_HOVER_EXIT)
        super.processGenericEvent(event);
    }
  }

  private static class AutoDetectTouchInput extends IcsTouchInput {
    int tapCount = 0;
    boolean hover = false, fingerHover = false, tap = false;
    float hoverX = 0.0f, hoverY = 0.0f;
    long hoverTime = 0;
    float tapX = 0.0f, tapY = 0.0f;
    long tapTime = 0;
    float hoverTouchDistance = 0.0f;

    private static class Holder {
      private static final AutoDetectTouchInput sInstance = new AutoDetectTouchInput();
    }

    public void process(final MotionEvent event) {
      if (((event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_UP ||
        (event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_DOWN)) {
        tapCount++;
        if ((event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_UP) {
          tap = true;
          tapX = event.getX();
          tapY = event.getY();
          tapTime = System.currentTimeMillis();
          if (hover)
            Log.i("SDL", "Tap tapX " + event.getX() + " tapY " + event.getX());
        } else if (hover && System.currentTimeMillis() < hoverTime + 1000) {
          hoverTouchDistance += Math.abs(hoverX - event.getX()) + Math.abs(hoverY - event.getY());
          Log.i("SDL", "Finger down event.getX() " + event.getX() + " hoverX " + hoverX + " event.getY() " + event.getY() + " hoverY " + hoverY + " hoverTouchDistance " + hoverTouchDistance);
        }
      }
      if (tapCount >= 4) {
        int displayHeight = 800;
        try {
          DisplayMetrics dm = new DisplayMetrics();
          MainActivity.instance.getWindowManager().getDefaultDisplay().getMetrics(dm);
          displayHeight = Math.min(dm.widthPixels, dm.heightPixels);
        } catch (Exception eeeee) {
        }
        Log.i("SDL", "AutoDetectTouchInput: hoverTouchDistance " + hoverTouchDistance + " threshold " + displayHeight / 2 + " hover " + hover + " fingerHover " + fingerHover);
        if (hoverTouchDistance > displayHeight / 2) {
          if (Globals.AppUsesMouse)
            Toast.makeText(MainActivity.instance, "Detected buggy touch panel, enabling workarounds", Toast.LENGTH_SHORT).show();
          touchInput = CrappyMtkTabletWithBrokenTouchDrivers.Holder.sInstance;
        } else {
          if (fingerHover) {
            if (Globals.AppUsesMouse)
              Toast.makeText(MainActivity.instance, "Finger hover capability detected", Toast.LENGTH_SHORT).show();
            if (Globals.FingerHover && (Globals.RelativeMouseMovement || Globals.LeftClickMethod != Mouse.LEFT_CLICK_NORMAL)) {
              if (Globals.RelativeMouseMovement)
                Globals.ShowScreenUnderFinger = Mouse.ZOOM_MAGNIFIER;
              Globals.RelativeMouseMovement = false;
              Globals.LeftClickMethod = Mouse.LEFT_CLICK_NORMAL;
            }
            Settings.applyMouseEmulationOptions();
          }
          if (Globals.GenerateSubframeTouchEvents)
            touchInput = IcsTouchInputWithHistory.Holder.sInstance;
          else
            touchInput = IcsTouchInput.Holder.sInstance;
        }
      }
      super.process(event);
    }

    public void processGenericEvent(final MotionEvent event) {
      super.processGenericEvent(event);
      if ((event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_HOVER_MOVE ||
        (event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_HOVER_ENTER ||
        (event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_HOVER_EXIT) {
        hover = true;
        hoverX = event.getX();
        hoverY = event.getY();
        hoverTime = System.currentTimeMillis();
        if (ExternalMouseDetected == 0 && (event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_HOVER_MOVE)
          fingerHover = true;
        if (tap && System.currentTimeMillis() < tapTime + 1000) {
          tap = false;
          hoverTouchDistance += Math.abs(tapX - hoverX) + Math.abs(tapY - hoverY);
          Log.i("SDL", "Hover hoverX " + hoverX + " tapX " + tapX + " hoverY " + hoverX + " tapY " + tapY + " hoverTouchDistance " + hoverTouchDistance);
        }
      }
    }
  }

  private static int gamepadIds[] = new int[4];

  public static int processGamepadDeviceId(InputDevice device) {
    if (device == null)
      return 0;
    int source = device.getSources();
    if ((source & InputDevice.SOURCE_CLASS_JOYSTICK) != InputDevice.SOURCE_CLASS_JOYSTICK &&
      (source & InputDevice.SOURCE_GAMEPAD) != InputDevice.SOURCE_GAMEPAD) {
      return 0;
    }
    int deviceId = device.getId();
    for (int i = 0; i < gamepadIds.length; i++) {
      if (gamepadIds[i] == deviceId)
        return i + 1;
    }
    for (int i = 0; i < gamepadIds.length; i++) {
      if (gamepadIds[i] == 0) {
        Log.i("SDL", "libSDL: gamepad added: deviceId " + deviceId + " gamepadId " + (i + 1));
        gamepadIds[i] = deviceId;
        return i + 1;
      }
    }
    return 0;
  }

  public static void registerInputManagerCallbacks(Context context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
      JellyBeanInputManager.Holder.sInstance.register(context);
    }
  }

  private static class JellyBeanInputManager {
    private static class Holder {
      private static final JellyBeanInputManager sInstance = new JellyBeanInputManager();
    }

    private static class Listener implements InputManager.InputDeviceListener {
      public void onInputDeviceAdded(int deviceId) {
      }

      public void onInputDeviceChanged(int deviceId) {
        onInputDeviceRemoved(deviceId);
      }

      public void onInputDeviceRemoved(int deviceId) {
        for (int i = 0; i < gamepadIds.length; i++) {
          if (gamepadIds[i] == deviceId) {
            Log.i("SDL", "libSDL: gamepad removed: deviceId " + deviceId + " gamepadId " + (i + 1));
            gamepadIds[i] = 0;
          }
        }
      }
    }

    public void register(Context context) {
      InputManager manager = (InputManager) context.getSystemService(Context.INPUT_SERVICE);
      manager.registerInputDeviceListener(new Listener(), null);
    }
  }
}

@SuppressWarnings("JniMissingFunction")
class DemoRenderer extends GLSurfaceView_SDL.Renderer {
  public DemoRenderer(NeoXorgViewClient client) {
    mClient = client;
    Clipboard.get().setListener(mClient.getContext(), new Runnable() {
      public void run() {
        nativeClipboardChanged();
      }
    });
  }

  public void onSurfaceCreated(GL10 gl, EGLConfig config) {
    Log.i("SDL", "libSDL: DemoRenderer.onSurfaceCreated(): paused " + mPaused + " mFirstTimeStart " + mFirstTimeStart);
    mGlSurfaceCreated = true;
    mGl = gl;
    if (!mPaused && !mFirstTimeStart)
      nativeGlContextRecreated();
    mFirstTimeStart = false;
  }

  public void onSurfaceChanged(GL10 gl, int w, int h) {
    Log.i("SDL", "libSDL: DemoRenderer.onSurfaceChanged(): paused " + mPaused + " mFirstTimeStart " + mFirstTimeStart + " w " + w + " h " + h);
    if (w < h && Globals.HorizontalOrientation) {
      int x = w;
      w = h;
      h = x;
    }
    mWidth = w - w % 2;
    mHeight = h - h % 2;
    mGl = gl;
    nativeResize(mWidth, mHeight, Globals.KeepAspectRatio ? 1 : 0);
  }

  int mLastPendingResize = 0;

  public void onWindowResize(final int w, final int h) {
    if (mClient.isRunningOnOUYA())
      return;
    Log.d("SDL", "libSDL: DemoRenderer.onWindowResize(): " + w + "x" + h);
    mLastPendingResize++;
    final int resizeThreadIndex = mLastPendingResize;
    mClient.getGLView().postDelayed(new Runnable() {
      public void run() {
        if (resizeThreadIndex != mLastPendingResize)
          return;
        int ww = w - w % 2;
        int hh = h - h % 2;
        View topView = mClient.getWindow().peekDecorView();
        if (topView != null && Globals.ImmersiveMode) {
          ww = topView.getWidth() - topView.getWidth() % 2;
          hh = topView.getHeight() - topView.getHeight() % 2;
        }

        Display display = mClient.getWindowManager().getDefaultDisplay();

        if (mWidth != 0 && mHeight != 0 && (mWidth != ww || mHeight != hh)) {
          Log.i("SDL", "libSDL: DemoRenderer.onWindowResize(): screen size changed from " + mWidth + "x" + mHeight + " to " + ww + "x" + hh);
          if (Globals.SwVideoMode &&
            (Math.abs(display.getWidth() - ww) > display.getWidth() / 10 ||
              Math.abs(display.getHeight() - hh) > display.getHeight() / 10)) {
            Log.i("SDL", "Multiwindow detected - enabling screen orientation autodetection");
            Globals.AutoDetectOrientation = true;
            mClient.initScreenOrientation();
            DemoRenderer.super.ResetVideoSurface();
            DemoRenderer.super.onWindowResize(ww, hh);
          } else {
            Log.i("SDL", "System button bar hidden - re-init video to avoid black bar at the top");
            DemoRenderer.super.ResetVideoSurface();
            DemoRenderer.super.onWindowResize(ww, hh);
          }
        }
        if (mWidth == 0 && mHeight == 0) {
          if ((ww > hh) != (display.getWidth() > display.getHeight())) {
            Log.i("SDL", "Multiwindow detected - app window size " + ww + "x" + hh + " but display dimensions are " + display.getWidth() + "x" + display.getHeight());
            Globals.AutoDetectOrientation = true;
          }
        }
        if (Globals.AutoDetectOrientation && (ww > hh) != (mWidth > mHeight))
          Globals.HorizontalOrientation = (ww > hh);
      }
    }, 2000);
  }

  public void onSurfaceDestroyed() {
    Log.i("SDL", "libSDL: DemoRenderer.onSurfaceDestroyed(): paused " + mPaused + " mFirstTimeStart " + mFirstTimeStart);
    mGlSurfaceCreated = false;
    mGlContextLost = true;
    nativeGlContextLost();
  }

  ;

  public void onDrawFrame(GL10 gl) {
    mGl = gl;
    SwapBuffers();

    nativeInitJavaCallbacks();

    mGlContextLost = false;

    Settings.Apply(mClient);
    Settings.nativeSetEnv("DISPLAY_RESOLUTION_WIDTH", String.valueOf(Math.max(mWidth, mHeight)));
    Settings.nativeSetEnv("DISPLAY_RESOLUTION_HEIGHT", String.valueOf(Math.min(mWidth, mHeight)));

    accelerometer = new NeoAccelerometerReader(mClient.getContext());
    if (Globals.MoveMouseWithGyroscope)
      startAccelerometerGyroscope(1);
    if (Globals.AudioBufferConfig >= 2)
      Thread.currentThread().setPriority((Thread.NORM_PRIORITY + Thread.MIN_PRIORITY) / 2);
    String commandline = Globals.CommandLine;
    nativeInit(Globals.DataDir,
      commandline,
      ((Globals.SwVideoMode && Globals.MultiThreadedVideo) || Globals.CompatibilityHacksVideo) ? 1 : 0,
      0);
    System.exit(0);
  }

  public int swapBuffers()
  {
    if (!super.SwapBuffers() && Globals.NonBlockingSwapBuffers) {
      if (mRatelimitTouchEvents) {
        synchronized (this) {
          this.notify();
        }
      }
      return 0;
    }

    if (mGlContextLost) {
      mGlContextLost = false;
      Settings.SetupTouchscreenKeyboardGraphics(mClient.getContext());
      super.SwapBuffers();
    }

    if (mRatelimitTouchEvents) {
      synchronized (this) {
        this.notify();
      }
    }
    if (mClient.isScreenKeyboardShown() && !mClient.isKeyboardWithoutTextInputShown()) {
      try {
        Thread.sleep(50);
      } catch (Exception e) {
      }
      ;
    }

    mOrientationFrameHackyCounter++;
    if (mOrientationFrameHackyCounter > 100) {
      mOrientationFrameHackyCounter = 0;
      mClient.updateScreenOrientation();
    }

    return 1;
  }

  public void showScreenKeyboardWithoutTextInputField()
  {
    mClient.showScreenKeyboardWithoutTextInputField(Globals.TextInputKeyboard);
  }

  public void showInternalScreenKeyboard(int keyboard)
  {
    mClient.showScreenKeyboardWithoutTextInputField(keyboard);
  }

  public void showScreenKeyboard(final String oldText, int unused)
  {
    class Callback implements Runnable {
      public NeoXorgViewClient client;
      public String oldText;

      public void run() {
        client.showScreenKeyboard(oldText);
      }
    }
    Callback cb = new Callback();
    cb.client = mClient;
    cb.oldText = oldText;
    mClient.runOnUiThread(cb);
  }

  public void hideScreenKeyboard()
  {
    class Callback implements Runnable {
      public NeoXorgViewClient client;

      public void run() {
        client.hideScreenKeyboard();
      }
    }
    Callback cb = new Callback();
    cb.client = mClient;
    mClient.runOnUiThread(cb);
  }

  public int isScreenKeyboardShown()
  {
    return mClient.isScreenKeyboardShown() ? 1 : 0;
  }

  public void setScreenKeyboardHintMessage(String s)
  {
    mClient.setScreenKeyboardHintMessage(s);
  }

  public void startAccelerometerGyroscope(int started)
  {
    accelerometer.openedBySDL = (started != 0);
    if (accelerometer.openedBySDL && !mPaused)
      accelerometer.start();
    else
      accelerometer.stop();
  }

  public String getClipboardText()
  {
    return Clipboard.get().get(mClient.getContext());
  }

  public void setClipboardText(final String s)
  {
    Clipboard.get().set(mClient.getContext(), s);
  }

  public void exitApp() {
    nativeDone();
  }

  public void getAdvertisementParams(int params[]) {
  }

  public void setAdvertisementVisible(int visible) {

  }

  public void setAdvertisementPosition(int left, int top) {
  }

  public void requestNewAdvertisement() {
  }

  public boolean cloudSave(final String filename, final String saveId, final String dialogTitle, final String description, final String imageFile, final long playedTimeMs) {
    return false;
  }

  public boolean cloudLoad(String filename, String saveId, String dialogTitle) {
    return false;
  }

  public void openExternalApp(String pkgName, String activity, String url) {
    try {
      Intent i = new Intent();
      if (url != null && url.length() > 0) {
        i.setAction(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
      }
      if (pkgName != null && activity != null && pkgName.length() > 0 && activity.length() > 0) {
        i.setClassName(pkgName, activity);
      }
      mClient.getContext().startActivity(i);
    } catch (Exception e) {
      Log.i("SDL", "libSDL: cannot start external app: " + e.toString());
    }
  }

  public void setSystemMousePointerVisible(int visible) {
    mClient.setSystemMousePointerVisible(visible);
  }

  public void restartMyself(String restartParams) {
  }

  public void setConfigOptionFromSDL(int option, int value) {
    Settings.setConfigOptionFromSDL(option, value);
  }

  private int PowerOf2(int i) {
    int value = 1;
    while (value < i)
      value <<= 1;
    return value;
  }

  private native void nativeInitJavaCallbacks();

  private native void nativeInit(String CurrentPath, String CommandLine, int multiThreadedVideo, int unused);

  private native void nativeResize(int w, int h, int keepAspectRatio);

  private native void nativeDone();

  private native void nativeGlContextLost();

  public native void nativeGlContextRecreated();

  public native void nativeGlContextLostAsyncEvent();

  public static native void nativeTextInput(int ascii, int unicode);

  public static native void nativeTextInputFinished();

  public static native void nativeClipboardChanged();

  private NeoXorgViewClient mClient = null;
  public AccelerometerReader accelerometer = null;

  private GL10 mGl = null;
  private EGL10 mEgl = null;
  private EGLDisplay mEglDisplay = null;
  private EGLSurface mEglSurface = null;
  private EGLContext mEglContext = null;
  private boolean mGlContextLost = false;
  public boolean mGlSurfaceCreated = false;
  public boolean mPaused = false;
  private boolean mFirstTimeStart = true;
  public int mWidth = 0;
  public int mHeight = 0;
  int mOrientationFrameHackyCounter = 0;

  public static final boolean mRatelimitTouchEvents = true;
}

@SuppressWarnings("JniMissingFunction")
class DemoGLSurfaceView extends GLSurfaceView_SDL {

  public DemoGLSurfaceView(NeoXorgViewClient client) {
    super(client.getContext());
    mClient = client;
    setEGLConfigChooser(Globals.VideoDepthBpp, Globals.NeedDepthBuffer, Globals.NeedStencilBuffer, Globals.NeedGles2, Globals.NeedGles3);
    mRenderer = new DemoRenderer(client);
    setRenderer(mRenderer);
    DifferentTouchInput.registerInputManagerCallbacks(client.getContext());
  }

  @Override
  public boolean onKeyDown(int keyCode, final KeyEvent event) {
    if (keyCode == KeyEvent.KEYCODE_BACK) {
      if ((event.getSource() & InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE) {
        nativeMouseButtonsPressed(2, 1);
        return true;
      } else if (mClient.isKeyboardWithoutTextInputShown()) {
        return true;
      }
    }

    if (nativeKey(keyCode, 1, event.getUnicodeChar(), DifferentTouchInput.processGamepadDeviceId(event.getDevice())) == 0)
      return super.onKeyDown(keyCode, event);

    return true;
  }

  @Override
  public boolean onKeyUp(int keyCode, final KeyEvent event) {
    if (keyCode == KeyEvent.KEYCODE_BACK) {
      if ((event.getSource() & InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE) {
        nativeMouseButtonsPressed(2, 0);
        return true;
      } else if (mClient.isKeyboardWithoutTextInputShown()) {
        mClient.showScreenKeyboardWithoutTextInputField(0);
        return true;
      }
    }

    if (nativeKey(keyCode, 0, event.getUnicodeChar(), DifferentTouchInput.processGamepadDeviceId(event.getDevice())) == 0)
      return super.onKeyUp(keyCode, event);

    return true;
  }

  @Override
  public boolean onKeyMultiple(int keyCode, int repeatCount, final KeyEvent event) {
    if (event.getCharacters() != null) {
      for (int i = 0; i < event.getCharacters().length(); i++) {
        nativeKey(event.getKeyCode(), 1, event.getCharacters().codePointAt(i), 0);
        nativeKey(event.getKeyCode(), 0, event.getCharacters().codePointAt(i), 0);
      }
    }
    return true;
  }

  @Override
  public boolean onTouchEvent(final MotionEvent event) {
    if (getX() != 0)
      event.offsetLocation(-getX(), -getY());
    DifferentTouchInput.touchInput.process(event);
    if (DemoRenderer.mRatelimitTouchEvents) {
      limitEventRate(event);
    }
    return true;
  }

  ;

  @Override
  public boolean onGenericMotionEvent(final MotionEvent event) {
    DifferentTouchInput.touchInput.processGenericEvent(event);
    if (DemoRenderer.mRatelimitTouchEvents) {
      limitEventRate(event);
    }
    return true;
  }

  public void limitEventRate(final MotionEvent event) {
    if ((event.getAction() == MotionEvent.ACTION_MOVE ||
      event.getAction() == MotionEvent.ACTION_HOVER_MOVE)) {
      synchronized (mRenderer) {
        try {
          mRenderer.wait(300L);
        } catch (InterruptedException e) {
          Log.v("SDL", "DemoGLSurfaceView::limitEventRate(): Who dared to interrupt my slumber?");
          Thread.interrupted();
        }
      }
    }
  }

  public void exitApp() {
    mRenderer.exitApp();
  }

  ;

  @Override
  public void onPause() {
    Log.i("SDL", "libSDL: DemoGLSurfaceView.onPause(): mRenderer.mGlSurfaceCreated " + mRenderer.mGlSurfaceCreated + " mRenderer.mPaused " + mRenderer.mPaused + (mRenderer.mPaused ? " - not doing anything" : ""));
    if (mRenderer.mPaused)
      return;
    mRenderer.mPaused = true;
    super.onPause();
    mRenderer.nativeGlContextLostAsyncEvent();
    if (mRenderer.accelerometer != null)
      mRenderer.accelerometer.stop();
  }

  ;

  public boolean isPaused() {
    return mRenderer.mPaused;
  }

  @Override
  public void onResume() {
    Log.i("SDL", "libSDL: DemoGLSurfaceView.onResume(): mRenderer.mGlSurfaceCreated " + mRenderer.mGlSurfaceCreated + " mRenderer.mPaused " + mRenderer.mPaused + (!mRenderer.mPaused ? " - not doing anything" : ""));
    if (!mRenderer.mPaused)
      return;
    mRenderer.mPaused = false;
    super.onResume();
    if (mRenderer.mGlSurfaceCreated && !mRenderer.mPaused || Globals.NonBlockingSwapBuffers)
      mRenderer.nativeGlContextRecreated();
    if (mRenderer.accelerometer != null && mRenderer.accelerometer.openedBySDL)
      mRenderer.accelerometer.start();
  }

  ;

  DemoRenderer mRenderer;
  NeoXorgViewClient mClient;

  public static native void nativeMotionEvent(int x, int y, int action, int pointerId, int pressure, int radius);

  public static native int nativeKey(int keyCode, int down, int unicode, int gamepadId);

  public static native void nativeHardwareMouseDetected(int detected);

  public static native void nativeMouseButtonsPressed(int buttonId, int pressedState);

  public static native void nativeMouseWheel(int scrollX, int scrollY);

  public static native void nativeGamepadAnalogJoystickInput(float stick1x, float stick1y, float stick2x, float stick2y, float ltrigger, float rtrigger, float dpadx, float dpady, int gamepadId);

  public static native void nativeScreenVisibleRect(int x, int y, int w, int h);

  public static native void nativeScreenKeyboardShown(int shown);
}
