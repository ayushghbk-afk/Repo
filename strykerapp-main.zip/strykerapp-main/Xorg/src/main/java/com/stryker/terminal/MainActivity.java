/*
Simple DirectMedia Layer
Java source code (C) 2009-2014 Sergii Pylypenko

This software is provided 'as-is', without any express or implied
warranty.  In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required. 
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/

package com.stryker.terminal;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.KeyguardManager;
import android.app.ProgressDialog;
import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.InputType;
import android.text.SpannedString;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.*;
import android.view.View.OnKeyListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.stryker.terminal.xorg.NeoXorgViewClient;
import com.stryker.terminal.xorg.R;

import java.util.LinkedList;
import java.util.TreeSet;
import java.util.concurrent.Semaphore;


public class MainActivity extends AppCompatActivity implements NeoXorgViewClient {
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    instance = this;
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
      WindowManager.LayoutParams.FLAG_FULLSCREEN);
    if (Globals.InhibitSuspend)
      getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

    Log.i("SDL", "libSDL: Creating startup screen");
    _layout = new LinearLayout(this);
    _layout.setOrientation(LinearLayout.VERTICAL);
    _layout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT));
    _layout2 = new LinearLayout(this);
    _layout2.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    loadingDialog = new ProgressDialog(this);
    loadingDialog.setMessage(getString(R.string.accessing_network));

    final Semaphore loadedLibraries = new Semaphore(0);

    if (Globals.StartupMenuButtonTimeout > 0) {
      _btn = new Button(this);
      _btn.setEnabled(false);
      _btn.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
      _btn.setText(getResources().getString(R.string.device_change_cfg));
      class onClickListener implements View.OnClickListener {
        public MainActivity p;

        onClickListener(MainActivity _p) {
          p = _p;
        }

        public void onClick(View v) {
          setUpStatusLabel();
          Log.i("SDL", "libSDL: User clicked change phone config button");
          loadedLibraries.acquireUninterruptibly();
          setScreenOrientation();
          SettingsMenu.showConfig(p, false);
        }
      }
      ;
      _btn.setOnClickListener(new onClickListener(this));

      _layout2.addView(_btn);
    }

    _layout.addView(_layout2);

    ImageView img = new ImageView(this);

    img.setScaleType(ImageView.ScaleType.FIT_CENTER);
    try {
      img.setImageDrawable(Drawable.createFromStream(getAssets().open("logo.png"), "logo.png"));
    } catch (Exception e) {
      img.setImageResource(R.drawable.publisherlogo);
    }
    img.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT));
    _layout.addView(img);

    _videoLayout = new FrameLayout(this);
    _videoLayout.addView(_layout);

    setContentView(_videoLayout);
    _videoLayout.setFocusable(true);
    _videoLayout.setFocusableInTouchMode(true);
    _videoLayout.requestFocus();

    class Callback implements Runnable {
      MainActivity p;

      Callback(MainActivity _p) {
        p = _p;
      }

      public void run() {
        try {
          Thread.sleep(200);
        } catch (InterruptedException e) {
        }
        ;

        if (p.mAudioThread == null) {
          Log.i("SDL", "libSDL: Loading libraries");
          p.LoadLibraries();
          p.mAudioThread = new AudioThread(p);
          Log.i("SDL", "libSDL: Loading settings");
          final Semaphore loaded = new Semaphore(0);
          class Callback2 implements Runnable {
            public MainActivity Parent;

            public void run() {
              Settings.Load(Parent);
              setScreenOrientation();
              loaded.release();
              loadedLibraries.release();
              if (_btn != null) {
                _btn.setEnabled(true);
                _btn.setFocusable(true);
                _btn.setFocusableInTouchMode(true);
                _btn.requestFocus();
              }
            }
          }
          Callback2 cb = new Callback2();
          cb.Parent = p;
          p.runOnUiThread(cb);
          loaded.acquireUninterruptibly();
          if (!Globals.CompatibilityHacksStaticInit)
            p.LoadApplicationLibrary(p);
        }

        if (!Settings.settingsChanged) {
          if (Globals.StartupMenuButtonTimeout > 0) {
            Log.i("SDL", "libSDL: " + String.valueOf(Globals.StartupMenuButtonTimeout) + "-msec timeout in startup screen");
            try {
              Thread.sleep(Globals.StartupMenuButtonTimeout);
            } catch (InterruptedException e) {
            }
            ;
          }
          if (Settings.settingsChanged)
            return;
        }
      }
    }
    ;
    (new Thread(new Callback(this))).start();
  }

  public void setUpStatusLabel() {
    MainActivity Parent = this;
    if (Parent._btn != null) {
      Parent._layout2.removeView(Parent._btn);
      Parent._btn = null;
    }
    if (Parent._tv == null) {
      Display display = getWindowManager().getDefaultDisplay();
      int width = display.getWidth();
      int height = display.getHeight();
      Parent._tv = new TextView(Parent);
      Parent._tv.setMaxLines(2);
      Parent._tv.setMinLines(2);
      Parent._tv.setText(R.string.init);
      Parent._tv.setPadding((int) (width * 0.1), (int) (height * 0.1), (int) (width * 0.1), 0);
      Parent._layout2.addView(Parent._tv);
    }
  }

  public void initSDL() {
    setScreenOrientation();
    updateScreenOrientation();
    DimSystemStatusBar.get().dim(_videoLayout);
    (new Thread(new Runnable() {
      public void run() {
        if (Globals.AutoDetectOrientation)
          Globals.HorizontalOrientation = isCurrentOrientationHorizontal();
        while (isCurrentOrientationHorizontal() != Globals.HorizontalOrientation ||
          ((KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE)).inKeyguardRestrictedInputMode()) {
          Log.d("SDL", "libSDL: Waiting for screen orientation to change to " + (Globals.HorizontalOrientation ? "landscape" : "portrait") + ", and for disabling lockscreen mode");
          try {
            Thread.sleep(500);
          } catch (Exception e) {
          }
          if (_isPaused) {
            Log.i("SDL", "libSDL: Application paused, cancelling SDL initialization until it will be brought to foreground");
            return;
          }
          DimSystemStatusBar.get().dim(_videoLayout);
        }
        runOnUiThread(new Runnable() {
          public void run() {
            DisplayMetrics dm = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(dm);
            if (Globals.ImmersiveMode && (_videoLayout.getHeight() != dm.widthPixels || _videoLayout.getWidth() != dm.heightPixels)) {
              DimSystemStatusBar.get().dim(_videoLayout);
              try {
                Thread.sleep(300);
              } catch (Exception e) {
              }
            }
            initSDLInternal();
          }
        });
      }
    })).start();
  }

  private void initSDLInternal() {
    if (sdlInited)
      return;
    Log.i("SDL", "libSDL: Initializing video and SDL application");

    sdlInited = true;
    DimSystemStatusBar.get().dim(_videoLayout);
    _videoLayout.removeView(_layout);
    _layout = null;
    _layout2 = null;
    _btn = null;
    _tv = null;
    _inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
    _videoLayout = new FrameLayout(this);
    SetLayerType.get().setLayerType(_videoLayout);
    setContentView(_videoLayout);
    mGLView = new NeoGLView(this);
    SetLayerType.get().setLayerType(mGLView);
    if (isRunningOnOUYA() && Globals.TvBorders) {
      RelativeLayout view = new RelativeLayout(this);
      RelativeLayout.LayoutParams layout;

      layout = new RelativeLayout.LayoutParams(getResources().getDimensionPixelOffset(R.dimen.screen_border_horizontal), RelativeLayout.LayoutParams.MATCH_PARENT);
      layout.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
      layout.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
      ImageView borderLeft = new ImageView(this);
      borderLeft.setId(R.id.left);
      borderLeft.setImageResource(R.drawable.tv_border_left);
      borderLeft.setScaleType(ImageView.ScaleType.FIT_XY);
      view.addView(borderLeft, layout);

      layout = new RelativeLayout.LayoutParams(getResources().getDimensionPixelOffset(R.dimen.screen_border_horizontal), RelativeLayout.LayoutParams.MATCH_PARENT);
      layout.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
      layout.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
      ImageView borderRight = new ImageView(this);
      borderRight.setId(R.id.right);
      borderRight.setImageResource(R.drawable.tv_border_left);
      borderRight.setScaleType(ImageView.ScaleType.FIT_XY);
      borderRight.setScaleX(-1f);
      view.addView(borderRight, layout);

      layout = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, getResources().getDimensionPixelOffset(R.dimen.screen_border_vertical));
      layout.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
      layout.addRule(RelativeLayout.RIGHT_OF, borderLeft.getId());
      layout.addRule(RelativeLayout.LEFT_OF, borderRight.getId());
      ImageView borderTop = new ImageView(this);
      borderTop.setId(R.id.top);
      borderTop.setImageResource(R.drawable.tv_border_top);
      borderTop.setScaleType(ImageView.ScaleType.FIT_XY);
      view.addView(borderTop, layout);

      layout = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, getResources().getDimensionPixelOffset(R.dimen.screen_border_vertical));
      layout.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE);
      layout.addRule(RelativeLayout.RIGHT_OF, borderLeft.getId());
      layout.addRule(RelativeLayout.LEFT_OF, borderRight.getId());
      ImageView borderBottom = new ImageView(this);
      borderBottom.setId(R.id.bottom);
      borderBottom.setImageResource(R.drawable.tv_border_top);
      borderBottom.setScaleType(ImageView.ScaleType.FIT_XY);
      borderBottom.setScaleY(-1f);
      view.addView(borderBottom, layout);

      layout = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
      layout.addRule(RelativeLayout.RIGHT_OF, borderLeft.getId());
      layout.addRule(RelativeLayout.LEFT_OF, borderRight.getId());
      layout.addRule(RelativeLayout.BELOW, borderTop.getId());
      layout.addRule(RelativeLayout.ABOVE, borderBottom.getId());
      mGLView.setLayoutParams(layout);

      view.addView(mGLView);

      _videoLayout.addView(view, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
    } else {
      _videoLayout.addView(mGLView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
    }
    mGLView.setFocusableInTouchMode(true);
    mGLView.setFocusable(true);
    mGLView.requestFocus();
    if (Globals.HideSystemMousePointer && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
      mGLView.setPointerIcon(android.view.PointerIcon.getSystemIcon(this, android.view.PointerIcon.TYPE_NULL));
    }

    DimSystemStatusBar.get().dim(_videoLayout);

    Rect r = new Rect();
    _videoLayout.getWindowVisibleDisplayFrame(r);
    mGLView.nativeScreenVisibleRect(r.left, r.top, r.right, r.bottom);
    _videoLayout.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
      public void onGlobalLayout() {
        final Rect r = new Rect();
        _videoLayout.getWindowVisibleDisplayFrame(r);
        final int heightDiff = _videoLayout.getRootView().getHeight() - _videoLayout.getHeight();
        final int widthDiff = _videoLayout.getRootView().getWidth() - _videoLayout.getWidth();
        Log.v("SDL", "Main window visible region changed: " + r.left + ":" + r.top + ":" + r.width() + ":" + r.height());
        _videoLayout.postDelayed(new Runnable() {
          public void run() {
            DimSystemStatusBar.get().dim(_videoLayout);
            mGLView.nativeScreenVisibleRect(r.left + widthDiff, r.top + heightDiff, r.width(), r.height());
          }
        }, 300);
        _videoLayout.postDelayed(new Runnable() {
          public void run() {
            DimSystemStatusBar.get().dim(_videoLayout);
            mGLView.nativeScreenVisibleRect(r.left + widthDiff, r.top + heightDiff, r.width(), r.height());
          }
        }, 600);
      }
    });
  }

  @Override
  protected void onPause() {
    _isPaused = true;
    if (mGLView != null)
      mGLView.onPause();
    super.onPause();
  }

  @Override
  protected void onResume() {
    super.onResume();
    if (mGLView != null) {
      DimSystemStatusBar.get().dim(_videoLayout);
      mGLView.onResume();
    }
    _isPaused = false;
    Intent i = new Intent("com.nvidia.intent.action.ENABLE_STYLUS");
    i.putExtra("package", getPackageName());
    sendBroadcast(i);
  }

  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    Log.i("SDL", "libSDL: onWindowFocusChanged: " + hasFocus + " - sending onPause/onResume");
    if (!hasFocus)
      onPause();
    else
      onResume();
  }

  public boolean isPaused() {
    return _isPaused;
  }

  @Override
  protected void onDestroy() {
    if (mGLView != null)
      mGLView.exitApp();
    super.onDestroy();
    try {
      Thread.sleep(2000);
    } catch (InterruptedException e) {
    }
    System.exit(0);
  }

  @Override
  protected void onStart() {
    super.onStart();
  }

  @Override
  protected void onStop() {
    super.onStop();
  }

  @Override
  public void onActivityResult(int request, int response, Intent data) {
    super.onActivityResult(request, response, data);
  }

  private int TextInputKeyboardList[][] =
    {
      {0, R.xml.qwerty, R.xml.c64, R.xml.amiga, R.xml.atari800},
      {0, R.xml.qwerty_shift, R.xml.c64, R.xml.amiga_shift, R.xml.atari800},
      {0, R.xml.qwerty_alt, R.xml.c64, R.xml.amiga_alt, R.xml.atari800},
      {0, R.xml.qwerty_alt_shift, R.xml.c64, R.xml.amiga_alt_shift, R.xml.atari800}
    };

  @Override
  public Context getContext() {
    return this;
  }

  @Override
  public boolean isKeyboardWithoutTextInputShown() {
    return keyboardWithoutTextInputShown;
  }

  public void showScreenKeyboardWithoutTextInputField(final int keyboard) {
    if (!isKeyboardWithoutTextInputShown()) {
      keyboardWithoutTextInputShown = true;
      runOnUiThread(new Runnable() {
        public void run() {
          if (keyboard == 0) {
            _inputManager.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
            _inputManager.showSoftInput(mGLView, InputMethodManager.SHOW_FORCED);
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
          } else {
            if (_screenKeyboard != null)
              return;
            class BuiltInKeyboardView extends KeyboardView {
              public boolean shift = false;
              public boolean alt = false;
              public TreeSet<Integer> stickyKeys = new TreeSet<Integer>();

              public BuiltInKeyboardView(Context context, android.util.AttributeSet attrs) {
                super(context, attrs);
              }

              public boolean dispatchTouchEvent(final MotionEvent ev) {
                if (ev.getY() < getTop())
                  return false;
                if (ev.getAction() == MotionEvent.ACTION_DOWN || ev.getAction() == MotionEvent.ACTION_UP || ev.getAction() == MotionEvent.ACTION_MOVE) {
                  MotionEvent converted = MotionEvent.obtain(ev.getDownTime(), ev.getEventTime(), ev.getAction(), ev.getX(), ev.getY() - (float) getTop(), ev.getMetaState());
                  return super.dispatchTouchEvent(converted);
                }
                return false;
              }

              public boolean onKeyDown(int key, final KeyEvent event) {
                return false;
              }

              public boolean onKeyUp(int key, final KeyEvent event) {
                return false;
              }

              public void ChangeKeyboard() {
                int idx = (shift ? 1 : 0) + (alt ? 2 : 0);
                setKeyboard(new Keyboard(MainActivity.this, TextInputKeyboardList[idx][keyboard]));
                setPreviewEnabled(false);
                setProximityCorrectionEnabled(false);
                for (Keyboard.Key k : getKeyboard().getKeys()) {
                  if (stickyKeys.contains(k.codes[0])) {
                    k.on = true;
                    invalidateAllKeys();
                  }
                }
              }
            }
            final BuiltInKeyboardView builtinKeyboard = new BuiltInKeyboardView(MainActivity.this, null);
            builtinKeyboard.setAlpha(0.7f);
            builtinKeyboard.ChangeKeyboard();
            builtinKeyboard.setOnKeyboardActionListener(new KeyboardView.OnKeyboardActionListener() {
              public void onPress(int key) {
                if (key == KeyEvent.KEYCODE_BACK)
                  return;
                if (key < 0)
                  return;
                for (Keyboard.Key k : builtinKeyboard.getKeyboard().getKeys()) {
                  if (k.sticky && key == k.codes[0])
                    return;
                }
                if (key > 100000) {
                  key -= 100000;
                  MainActivity.this.onKeyDown(KeyEvent.KEYCODE_SHIFT_LEFT, new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_SHIFT_LEFT));
                }
                MainActivity.this.onKeyDown(key, new KeyEvent(KeyEvent.ACTION_DOWN, key));
              }

              public void onRelease(int key) {
                if (key == KeyEvent.KEYCODE_BACK) {
                  builtinKeyboard.setOnKeyboardActionListener(null);
                  showScreenKeyboardWithoutTextInputField(0);
                  return;
                }
                if (key == Keyboard.KEYCODE_SHIFT) {
                  builtinKeyboard.shift = !builtinKeyboard.shift;
                  if (builtinKeyboard.shift && !builtinKeyboard.alt)
                    MainActivity.this.onKeyDown(KeyEvent.KEYCODE_SHIFT_LEFT, new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_SHIFT_LEFT));
                  else
                    MainActivity.this.onKeyUp(KeyEvent.KEYCODE_SHIFT_LEFT, new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_SHIFT_LEFT));
                  builtinKeyboard.ChangeKeyboard();
                  return;
                }
                if (key == Keyboard.KEYCODE_ALT) {
                  builtinKeyboard.alt = !builtinKeyboard.alt;
                  if (builtinKeyboard.alt)
                    MainActivity.this.onKeyUp(KeyEvent.KEYCODE_SHIFT_LEFT, new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_SHIFT_LEFT));
                  else
                    builtinKeyboard.shift = false;
                  builtinKeyboard.ChangeKeyboard();
                  return;
                }
                if (key < 0)
                  return;
                for (Keyboard.Key k : builtinKeyboard.getKeyboard().getKeys()) {
                  if (k.sticky && key == k.codes[0]) {
                    if (k.on) {
                      builtinKeyboard.stickyKeys.add(key);
                      MainActivity.this.onKeyDown(key, new KeyEvent(KeyEvent.ACTION_DOWN, key));
                    } else {
                      builtinKeyboard.stickyKeys.remove(key);
                      MainActivity.this.onKeyUp(key, new KeyEvent(KeyEvent.ACTION_UP, key));
                    }
                    return;
                  }
                }

                boolean shifted = false;
                if (key > 100000) {
                  key -= 100000;
                  shifted = true;
                }

                MainActivity.this.onKeyUp(key, new KeyEvent(KeyEvent.ACTION_UP, key));

                if (shifted) {
                  MainActivity.this.onKeyUp(KeyEvent.KEYCODE_SHIFT_LEFT, new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_SHIFT_LEFT));
                  builtinKeyboard.stickyKeys.remove(KeyEvent.KEYCODE_SHIFT_LEFT);
                  for (Keyboard.Key k : builtinKeyboard.getKeyboard().getKeys()) {
                    if (k.sticky && k.codes[0] == KeyEvent.KEYCODE_SHIFT_LEFT && k.on) {
                      k.on = false;
                      builtinKeyboard.invalidateAllKeys();
                    }
                  }
                }
              }

              public void onText(CharSequence p1) {
              }

              public void swipeLeft() {
              }

              public void swipeRight() {
              }

              public void swipeDown() {
              }

              public void swipeUp() {
              }

              public void onKey(int p1, int[] p2) {
              }
            });
            _screenKeyboard = builtinKeyboard;
            FrameLayout.LayoutParams layout = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
            _videoLayout.addView(_screenKeyboard, layout);
          }
        }
      });
    } else {
      keyboardWithoutTextInputShown = false;
      runOnUiThread(new Runnable() {
        public void run() {
          if (_screenKeyboard != null) {
            _videoLayout.removeView(_screenKeyboard);
            _screenKeyboard = null;
          }
          getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
          _inputManager.hideSoftInputFromWindow(mGLView.getWindowToken(), 0);
          DimSystemStatusBar.get().dim(_videoLayout);
        }
      });
    }
    mGLView.nativeScreenKeyboardShown(keyboardWithoutTextInputShown ? 1 : 0);
  }

  public void showScreenKeyboard(final String oldText) {
    if (Globals.CompatibilityHacksTextInputEmulatesHwKeyboard) {
      showScreenKeyboardWithoutTextInputField(Globals.TextInputKeyboard);
      return;
    }
    if (_screenKeyboard != null)
      return;
    class simpleKeyListener implements OnKeyListener {
      MainActivity _parent;

      simpleKeyListener(MainActivity parent) {
        _parent = parent;
      }

      ;

      public boolean onKey(View v, int keyCode, KeyEvent event) {
        if ((event.getAction() == KeyEvent.ACTION_UP) && (
          keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_BACK ||
            keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_BUTTON_A ||
            keyCode == KeyEvent.KEYCODE_BUTTON_B ||
            keyCode == KeyEvent.KEYCODE_BUTTON_X ||
            keyCode == KeyEvent.KEYCODE_BUTTON_Y ||
            keyCode == KeyEvent.KEYCODE_BUTTON_1 ||
            keyCode == KeyEvent.KEYCODE_BUTTON_2 ||
            keyCode == KeyEvent.KEYCODE_BUTTON_3 ||
            keyCode == KeyEvent.KEYCODE_BUTTON_4)) {
          _parent.hideScreenKeyboard();
          return true;
        }
        return false;
      }
    }
    ;
    EditText screenKeyboard = new EditText(this, null,
      android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP ? android.R.style.TextAppearance_Material_Widget_EditText : android.R.style.TextAppearance_Widget_EditText);
    String hint = _screenKeyboardHintMessage;
    screenKeyboard.setHint(hint != null ? hint : getString(R.string.text_edit_click_here));
    screenKeyboard.setText(oldText);
    screenKeyboard.setSelection(screenKeyboard.getText().length());
    screenKeyboard.setOnKeyListener(new simpleKeyListener(this));
    screenKeyboard.setBackgroundColor(this.getResources().getColor(android.R.color.primary_text_light));
    screenKeyboard.setTextColor(this.getResources().getColor(android.R.color.background_light));
    if (isRunningOnOUYA() && Globals.TvBorders)
      screenKeyboard.setPadding(100, 100, 100, 100);
    _screenKeyboard = screenKeyboard;
    _videoLayout.addView(_screenKeyboard);
    screenKeyboard.setInputType(InputType.TYPE_CLASS_TEXT);
    screenKeyboard.setFocusableInTouchMode(true);
    screenKeyboard.setFocusable(true);
    final EditText keyboard = screenKeyboard;
    keyboard.postDelayed(new Runnable() {
      public void run() {
        keyboard.requestFocus();
        keyboard.dispatchTouchEvent(MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), MotionEvent.ACTION_DOWN, 0, 0, 0));
        keyboard.dispatchTouchEvent(MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, 0, 0, 0));
        keyboard.postDelayed(new Runnable() {
          public void run() {
            keyboard.requestFocus();
            keyboard.setSelection(keyboard.getText().length());
          }
        }, 100);
      }
    }, 300);
  }

  ;

  public void hideScreenKeyboard() {
    if (keyboardWithoutTextInputShown)
      showScreenKeyboardWithoutTextInputField(Globals.TextInputKeyboard);

    if (_screenKeyboard == null || !(_screenKeyboard instanceof EditText))
      return;

    synchronized (textInput) {
      String text = ((EditText) _screenKeyboard).getText().toString();
      for (int i = 0; i < text.length(); i++) {
        DemoRenderer.nativeTextInput((int) text.charAt(i), (int) text.codePointAt(i));
      }
    }
    DemoRenderer.nativeTextInputFinished();
    _inputManager.hideSoftInputFromWindow(_screenKeyboard.getWindowToken(), 0);
    _videoLayout.removeView(_screenKeyboard);
    _screenKeyboard = null;
    mGLView.setFocusableInTouchMode(true);
    mGLView.setFocusable(true);
    mGLView.requestFocus();
    DimSystemStatusBar.get().dim(_videoLayout);

    _videoLayout.postDelayed(new Runnable() {
      public void run() {
        DimSystemStatusBar.get().dim(_videoLayout);
      }
    }, 500);
  }

  ;

  public boolean isScreenKeyboardShown() {
    return _screenKeyboard != null;
  }

  ;

  public void setScreenKeyboardHintMessage(String s) {
    _screenKeyboardHintMessage = s;
    runOnUiThread(new Runnable() {
      public void run() {
        if (_screenKeyboard != null && _screenKeyboard instanceof EditText) {
          String hint = _screenKeyboardHintMessage;
          ((EditText) _screenKeyboard).setHint(hint != null ? hint : getString(R.string.text_edit_click_here));
        }
      }
    });
  }

  final static int ADVERTISEMENT_POSITION_RIGHT = -1;
  final static int ADVERTISEMENT_POSITION_BOTTOM = -1;
  final static int ADVERTISEMENT_POSITION_CENTER = -2;

  @Override
  public void onConfigurationChanged(Configuration newConfig) {
    super.onConfigurationChanged(newConfig);
    updateScreenOrientation();
  }

  public void updateScreenOrientation() {
    int rotation = Surface.ROTATION_0;
    rotation = getWindowManager().getDefaultDisplay().getRotation();
    AccelerometerReader.gyro.invertedOrientation = (rotation == Surface.ROTATION_180 || rotation == Surface.ROTATION_270);
  }

  @Override
  public void initScreenOrientation() {
    setScreenOrientation();
  }

  public void setText(final String t) {
    class Callback implements Runnable {
      MainActivity Parent;
      public SpannedString text;

      public void run() {
        Parent.setUpStatusLabel();
        if (Parent._tv != null)
          Parent._tv.setText(text);
      }
    }
    Callback cb = new Callback();
    cb.text = new SpannedString(t);
    cb.Parent = this;
    this.runOnUiThread(cb);
  }

  @Override
  public void onNewIntent(Intent i) {
    Log.i("SDL", "onNewIntent(): " + i.toString());
    super.onNewIntent(i);
    setIntent(i);
  }

  @SuppressLint("UnsafeDynamicallyLoadedCode")
  public void LoadLibraries() {
    try {
      if (Globals.NeedGles3) {
        System.loadLibrary("GLESv3");
        Log.i("SDL", "libSDL: loaded GLESv3 lib");
      } else if (Globals.NeedGles2) {
        System.loadLibrary("GLESv2");
        Log.i("SDL", "libSDL: loaded GLESv2 lib");
      }
    } catch (UnsatisfiedLinkError e) {
      Log.i("SDL", "libSDL: Cannot load GLESv3 or GLESv2 lib");
    }

    try {
      for (String libname : Globals.XLIBS) {
        String soPath = Globals.XLIB_DIR + libname;
        Log.i("SDL", "libSDL: loading lib " + soPath);
        try {
          System.load(soPath);
        } catch (UnsatisfiedLinkError error) {
          Log.i("SDL", "libSDL: error loading lib " + soPath
            + ", reason: " + error.getLocalizedMessage());
        }
      }
    } catch (UnsatisfiedLinkError ignore) {
    }
  }

  @SuppressLint("UnsafeDynamicallyLoadedCode")
  public static void LoadApplicationLibrary(final Context context) {
    Settings.nativeChdir(Globals.DataDir);
    try {
      for (String libname : Globals.XAPP_LIBS) {
        String soPath = Globals.XLIB_DIR + libname;
        Log.i("SDL", "libSDL: loading lib " + soPath);
        try {
          System.load(soPath);
        } catch (UnsatisfiedLinkError error) {
          Log.i("SDL", "libSDL: error loading lib " + soPath
            + ", reason: " + error.getLocalizedMessage());
        }
      }
    } catch (UnsatisfiedLinkError ignore) {
    }
    Log.v("SDL", "libSDL: loaded all libraries");
    ApplicationLibraryLoaded = true;
  }

  public int getApplicationVersion() {
    try {
      PackageInfo packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
      return packageInfo.versionCode;
    } catch (PackageManager.NameNotFoundException e) {
      Log.i("SDL", "libSDL: Cannot get the version of our own package: " + e);
    }
    return 0;
  }

  public boolean isRunningOnOUYA() {
    try {
      PackageInfo packageInfo = getPackageManager().getPackageInfo("tv.ouya", 0);
      return true;
    } catch (PackageManager.NameNotFoundException e) {
    }
    UiModeManager uiModeManager = (UiModeManager) getSystemService(UI_MODE_SERVICE);
    return (uiModeManager.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION) || Globals.OuyaEmulation;
  }

  @Override
  public NeoGLView getGLView() {
    return mGLView;
  }

  public boolean isCurrentOrientationHorizontal() {
    if (Globals.AutoDetectOrientation) {
      View topView = getWindow().peekDecorView();
      if (topView != null) {
        return topView.getWidth() >= topView.getHeight();
      }
    }
    Display getOrient = getWindowManager().getDefaultDisplay();
    return getOrient.getWidth() >= getOrient.getHeight();
  }

  void setScreenOrientation() {
    Globals.AutoDetectOrientation = true;
    if (Globals.AutoDetectOrientation) {
      setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_USER);
      return;
    }
    setRequestedOrientation(Globals.HorizontalOrientation ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
  }

  @Override
  public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
    if (permissions.length == 0 || grantResults.length == 0) {
      Log.i("SDL", "libSDL: Permission request dialog was aborted");
      return;
    }
    if (Manifest.permission.RECORD_AUDIO.equals(permissions[0])) {
      Log.i("SDL", "libSDL: Record audio permission: " + (grantResults[0] == PackageManager.PERMISSION_GRANTED ? "GRANTED" : "DENIED"));
    }
    if (Manifest.permission.WRITE_EXTERNAL_STORAGE.equals(permissions[0])) {
      Log.i("SDL", "libSDL: Write external storage permission: " + (grantResults[0] == PackageManager.PERMISSION_GRANTED ? "GRANTED" : "DENIED"));
      writeExternalStoragePermissionDialogAnswered = true;
    }
  }

  public void setSystemMousePointerVisible(int visible) {
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
      mGLView.setPointerIcon(android.view.PointerIcon.getSystemIcon(this, (visible == 0) ? android.view.PointerIcon.TYPE_NULL : android.view.PointerIcon.TYPE_DEFAULT));
    }
  }

  public FrameLayout getVideoLayout() {
    return _videoLayout;
  }

  NeoGLView mGLView = null;
  private static AudioThread mAudioThread = null;

  private TextView _tv = null;
  private Button _btn = null;
  private LinearLayout _layout = null;
  private LinearLayout _layout2 = null;
  public ProgressDialog loadingDialog = null;

  FrameLayout _videoLayout = null;
  private View _screenKeyboard = null;
  private String _screenKeyboardHintMessage = null;
  static boolean keyboardWithoutTextInputShown = false;
  private boolean sdlInited = false;
  public static boolean ApplicationLibraryLoaded = false;

  boolean _isPaused = false;
  private InputMethodManager _inputManager = null;

  public LinkedList<Integer> textInput = new LinkedList<Integer>();
  public static MainActivity instance = null;
  public boolean writeExternalStoragePermissionDialogAnswered = false;
}

abstract class DimSystemStatusBar {
  public static DimSystemStatusBar get() {
    return DimSystemStatusBarHoneycomb.Holder.sInstance;
  }

  public abstract void dim(final View view);

  private static class DimSystemStatusBarHoneycomb extends DimSystemStatusBar {
    private static class Holder {
      private static final DimSystemStatusBarHoneycomb sInstance = new DimSystemStatusBarHoneycomb();
    }

    public void dim(final View view) {
      if (Globals.ImmersiveMode)
        view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN);
      else
        view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE);
    }
  }
}

abstract class SetLayerType {
  public static SetLayerType get() {
    return SetLayerTypeHoneycomb.Holder.sInstance;
  }

  public abstract void setLayerType(final View view);

  private static class SetLayerTypeHoneycomb extends SetLayerType {
    private static class Holder {
      private static final SetLayerTypeHoneycomb sInstance = new SetLayerTypeHoneycomb();
    }

    public void setLayerType(final View view) {
      view.setLayerType(View.LAYER_TYPE_NONE, null);
    }
  }
}
